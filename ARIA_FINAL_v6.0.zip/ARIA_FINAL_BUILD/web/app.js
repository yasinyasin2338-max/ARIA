const $ = (s) => document.querySelector(s);
const chat = $('#chat'), input = $('#input'), send = $('#send'), mic = $('#mic'), status = $('#status');
const KEY = 'aria_state_v6';
let state = JSON.parse(localStorage.getItem(KEY) || 'null') || { messages: [], memory: '', web: true, speak: false };
let controller = null;

function save() { localStorage.setItem(KEY, JSON.stringify(state)); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
function scrollBottom() { chat.scrollTop = chat.scrollHeight; }
function render() {
  chat.innerHTML = '';
  if (!state.messages.length) {
    chat.innerHTML = `<section class="welcome"><div class="hero-orb">A</div><h1>سلام، من آریا هستم</h1><p>دستیار شخصی تو؛ فارسی، سریع و قابل توسعه.</p><div class="chips"><button class="chip">یه برنامه برام بساز</button><button class="chip">آخرین اخبار رو بررسی کن</button><button class="chip">کمکم کن تصمیم بگیرم</button></div></section>`;
    return;
  }
  for (const m of state.messages) {
    const d = document.createElement('article'); d.className = `msg ${m.role}`;
    const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.innerHTML = esc(m.content);
    const actions = document.createElement('div'); actions.className = 'msg-actions';
    if (m.role === 'assistant') {
      const copy = document.createElement('button'); copy.textContent = 'کپی'; copy.onclick = () => navigator.clipboard?.writeText(m.content);
      actions.append(copy);
    }
    d.append(bubble, actions); chat.appendChild(d);
  }
  scrollBottom();
}
function add(role, content) { state.messages.push({ role, content, at: Date.now() }); save(); render(); }
function setBusy(busy) { send.disabled = busy; input.disabled = busy; mic.disabled = busy; status.textContent = busy ? 'در حال فکر کردن…' : 'آماده‌ام'; }

async function ask(text) {
  text = text.trim(); if (!text || send.disabled) return;
  add('user', text); input.value = ''; input.style.height = 'auto'; setBusy(true);
  controller = new AbortController();
  try {
    const r = await fetch('/api/chat', { method:'POST', headers:{'content-type':'application/json'}, signal:controller.signal,
      body: JSON.stringify({ messages: state.messages.map(({role,content}) => ({role,content})), memory: state.memory, webSearch: state.web }) });
    const j = await r.json(); if (!r.ok) throw Error(j.error || 'خطا');
    add('assistant', j.text); if (state.speak) speak(j.text);
  } catch (e) {
    if (e.name !== 'AbortError') add('assistant', 'خطا در اتصال به سرور: ' + e.message);
  } finally { controller = null; setBusy(false); }
}

send.onclick = () => ask(input.value);
input.addEventListener('input', () => { input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,140)+'px'; });
input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input.value); } });
document.addEventListener('click', e => { if (e.target.classList.contains('chip')) ask(e.target.textContent); });

function speak(t) { if ('speechSynthesis' in window) { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t); u.lang='fa-IR'; u.rate=.98; speechSynthesis.speak(u); } }
function toggleSpeak() { state.speak = !state.speak; save(); $('#voiceOut').textContent = state.speak ? '🔊' : '🔇'; }
$('#voiceOut').onclick = toggleSpeak;

let rec = null;
if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
  const R = window.SpeechRecognition || window.webkitSpeechRecognition; rec = new R(); rec.lang='fa-IR'; rec.interimResults=false;
  rec.onstart=()=>{mic.classList.add('on');status.textContent='دارم گوش می‌دم…'};
  rec.onend=()=>{mic.classList.remove('on');status.textContent='آماده‌ام'};
  rec.onresult=e=>ask(e.results[0][0].transcript);
  rec.onerror=()=>{mic.classList.remove('on');status.textContent='میکروفون در دسترس نیست'};
}
mic.onclick = () => rec ? rec.start() : (status.textContent='تشخیص گفتار این مرورگر پشتیبانی نمی‌شود');

const panel = $('#panel');
$('#settings').onclick=()=>{ panel.classList.add('show'); $('#web').checked=state.web; $('#speak').checked=state.speak; $('#memory').value=state.memory; };
$('#close').onclick=()=>panel.classList.remove('show');
$('#web').onchange=e=>{state.web=e.target.checked;save()};
$('#speak').onchange=e=>{state.speak=e.target.checked;save();$('#voiceOut').textContent=state.speak?'🔊':'🔇'};
$('#memory').oninput=e=>{state.memory=e.target.value;save()};
$('#clear').onclick=()=>{if(confirm('همه گفتگوها و حافظه محلی پاک شود؟')){state={messages:[],memory:'',web:true,speak:false};save();render();panel.classList.remove('show');}};
$('#export').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}));a.download='aria-memory.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
$('#stop').onclick=()=>{controller?.abort();speechSynthesis?.cancel();setBusy(false)};

fetch('/api/health').then(r=>r.json()).then(h=>{ if(!h.configured) status.textContent='سرور آماده نیست: API Key تنظیم نشده'; }).catch(()=>status.textContent='اتصال به سرور برقرار نیست');
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
render(); $('#voiceOut').textContent=state.speak?'🔊':'🔇';
