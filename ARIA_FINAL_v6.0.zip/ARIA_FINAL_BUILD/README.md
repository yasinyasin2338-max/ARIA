# ARIA — دستیار شخصی فارسی

نسخه نهایی یک PWA موبایل‌محور با رابط فارسی RTL و بک‌اند Node/Express برای OpenAI Responses API.

## امکانات
- چت فارسی با نگهداری محلی گفتگو
- حافظه قابل ویرایش کاربر
- جستجوی وب از طریق ابزار رسمی Responses API
- ورودی صوتی مرورگر و پاسخ صوتی
- خروجی JSON از گفتگو و حافظه
- PWA قابل نصب روی موبایل
- API key فقط در سمت سرور
- endpoint سلامت `/api/health`
- مناسب اجرای محلی و استقرار روی Vercel

## اجرا
```bash
cd server
npm install
OPENAI_API_KEY="..." npm start
```
سپس `http://localhost:8787` را باز کن.

## تنظیمات محیطی
- `OPENAI_API_KEY` الزامی
- `ARIA_MODEL` پیش‌فرض `gpt-5.6-luna`
- `ARIA_WEB_SEARCH` پیش‌فرض `true`

برای Vercel، متغیرهای محیطی را در Project Settings اضافه کن. کلید API را داخل کد یا مرورگر قرار نده.

## نکته
PWA معمولی نمی‌تواند به‌صورت دائمی در پس‌زمینه به فرمان بیدارباش گوش کند؛ برای wake-word واقعی باید نسخه native اندروید و سرویس صوتی سیستم ساخته شود.
