# ARIA ULTRA

Private Persian-first personal AI web app with:
- OpenAI Responses API chat
- Optional live web search
- High-quality image generation endpoint
- Local conversation/memory storage
- Persian speech input/output in supported browsers
- Optional private bearer-token access
- Render-ready Node/Express deployment

## Environment
Set `OPENAI_API_KEY`. For private access also set `ARIA_ACCESS_TOKEN` to a long random secret. Never commit secrets.

## Run
`npm --prefix server install --omit=dev && npm start`

## Render
Use Node runtime, build `npm --prefix server install --omit=dev`, start `node server/index.js`.
