# ARIA Phone Ready
نسخه موبایل‌محور ARIA برای اجرا و نصب به شکل PWA.

برای هوش ابری واقعی، `worker.js` را روی Cloudflare Workers قرار بده و متغیر مخفی `OPENAI_API_KEY` را در همان سرویس تنظیم کن. کلید نباید داخل HTML/JavaScript قرار گیرد.

پس از انتشار Worker، آدرس آن را در `localStorage` با کلید `aria_endpoint` ذخیره کن یا app.js را با آدرس API منتشرشده تنظیم کن.

توجه: مرورگر معمولی نمی‌تواند میکروفون را به‌صورت دائمی در پس‌زمینه فعال نگه دارد؛ برای حالت دستیار پیش‌فرض/همیشه‌فعال باید اپ Android با VoiceInteractionService ساخته شود.
