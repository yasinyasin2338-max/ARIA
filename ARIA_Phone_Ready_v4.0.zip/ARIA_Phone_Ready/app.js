const chat=document.querySelector('#chat'),input=document.querySelector('#input');
const KEY='aria_endpoint';
function add(t,c){const d=document.createElement('div');d.className='msg '+c;d.textContent=t;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
async function send(t){if(!t.trim())return;add(t,'me');input.value='';let endpoint=localStorage.getItem(KEY)||'/api/chat';try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:t})});if(!r.ok)throw 0;const j=await r.json();add(j.reply||'پاسخی دریافت نشد.','ai');}catch(e){add('اتصال ARIA هنوز تنظیم نشده است. در مرحله راه‌اندازی، آدرس سرور را در تنظیمات مرورگر/پروژه وارد کن.','ai')}}
document.querySelector('#form').onsubmit=e=>{e.preventDefault();send(input.value)};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(SR){const sr=new SR();sr.lang='fa-IR';sr.interimResults=false;document.querySelector('#mic').onclick=()=>{sr.start()};sr.onresult=e=>{input.value=e.results[0][0].transcript;send(input.value)}}else document.querySelector('#mic').disabled=true;
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js');
