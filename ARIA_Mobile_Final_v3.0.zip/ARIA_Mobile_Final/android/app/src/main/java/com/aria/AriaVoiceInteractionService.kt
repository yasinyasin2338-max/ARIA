package com.aria

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService

/** System-level voice assistant service. Android keeps the selected VoiceInteractionService alive. */
class AriaVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        // Keep this service lightweight; the UI/session is created only when invoked.
    }

    override fun onLaunchVoiceAssistFromKeyguard() {
        showSession(Bundle(), 0)
    }
}
