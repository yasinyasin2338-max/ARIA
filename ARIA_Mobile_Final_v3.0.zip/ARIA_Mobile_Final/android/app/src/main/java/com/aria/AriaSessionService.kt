package com.aria

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class AriaSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AriaVoiceSession(this)
}

class AriaVoiceSession(context: android.content.Context) : VoiceInteractionSession(context) {
    override fun onCreate() {
        super.onCreate()
        // The system invokes this session for assistant interactions.
        // The full UI can be hosted by MainActivity/WebView while the session remains lightweight.
    }
}
