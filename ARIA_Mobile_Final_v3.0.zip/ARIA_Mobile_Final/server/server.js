import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';

const app=express();
const port=Number(process.env.PORT||8787);
const origin=process.env.ALLOWED_ORIGIN||'*';
app.use(cors({origin}));
app.use(express.json({limit:'4mb'}));
app.use(rateLimit({windowMs:60_000,max:60,standardHeaders:true,legacyHeaders:false}));
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const model=process.env.OPENAI_MODEL||'gpt-5';
const instructions=`You are ARIA, the user's Persian-first personal AI companion. Be extremely capable, fast, concise unless detail is useful, and natural. Prefer Persian when the user speaks Persian. Maintain continuity using the supplied conversation and user-approved memory. Help with research, writing, coding, planning, analysis, learning, images/files and practical tasks. Never claim an action was performed unless the connected tool actually performed it. Never claim unrestricted access to a phone, accounts or the physical world. Respect platform, legal, privacy and safety requirements. If a requested capability is unavailable, say so briefly and provide the closest practical path.`;
app.get('/health',(_,res)=>res.json({ok:true,service:'ARIA',model}));
app.post('/v1/chat',async(req,res)=>{
  try{
    const {messages=[],memory=[]}=req.body||{};
    const safe=Array.isArray(messages)?messages.slice(-50).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'').slice(0,16000)})):[];
    const mem=Array.isArray(memory)?memory.slice(0,100).map(x=>String(x).slice(0,1200)).filter(Boolean):[];
    const memoryBlock=mem.length?`\n\nUSER-APPROVED MEMORY:\n${mem.map(x=>'- '+x).join('\n')}`:'';
    const response=await client.responses.create({model,instructions:instructions+memoryBlock,input:safe});
    res.json({reply:response.output_text||'پاسخی دریافت نشد.'});
  }catch(err){console.error(err);res.status(500).json({error:'ARIA server error'});}
});
app.listen(port,()=>console.log(`ARIA listening on ${port}`));
