# ARIA Mobile — Final architecture

Phone-first ARIA assistant with Persian RTL UI, OpenAI backend, local memory, PWA support, and Android VoiceInteractionService integration.

## Voice always-on
Android keeps the user-selected VoiceInteractionService alive for hotword/voice-assistant interactions. The user must explicitly select ARIA as the phone assistant and grant microphone permission. Normal apps cannot silently enable themselves as the system assistant.

## Backend
Set OPENAI_API_KEY on the server. Never put the key in the mobile/web client.

## APK
The Android project is configured for a GitHub Actions debug build. Trigger the `Build ARIA APK` workflow after uploading this project to a GitHub repository; the APK is produced as a workflow artifact.
