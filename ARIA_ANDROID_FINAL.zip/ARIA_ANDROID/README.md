# ARIA Android

ARIA Android wrapper project for the ARIA ULTRA web application.

## Build

Open this folder in Android Studio and build the `app` module. The included GitHub Actions workflow can build `app-debug.apk` automatically in a repository with Actions enabled.

**Important:** the app UI is packaged locally, but chat/image API requests require the ARIA backend URL to be configured. The current frontend expects `/api/chat`, `/api/image`, and `/api/health` from its backend.
