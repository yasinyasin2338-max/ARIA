# ARIA — Mobile Companion

A phone-first Persian RTL PWA + secure Node backend.

## Included
- Persian RTL chat UI
- OpenAI Responses API backend (API key stays server-side)
- Optional built-in web search tool
- Local-first conversation memory
- Voice input with browser speech recognition when supported
- Spoken replies with browser speech synthesis
- Installable PWA
- Export/import memory
- Clear local data
- Vercel deployment config

## Important
This package is the complete deployable software project, but deployment and installation on a user's phone require the user to authorize the hosting/account and Android permissions. A normal PWA cannot continuously listen in the background; true always-on wake-word behavior requires an Android system voice-assistant implementation.

## Server environment
OPENAI_API_KEY=...
ARIA_MODEL=gpt-5.6-luna
ARIA_WEB_SEARCH=true

Run:
  cd server
  npm install
  npm start

Then open http://localhost:8787 (or deploy the project).
